import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Login")

	public class Login extends HttpServlet
	{
		public void service(HttpServletRequest request,HttpServletResponse response)
		{
			String custid = request.getParameter("custid");
			String pwd = request.getParameter("pwd");
			BankingModel m = new BankingModel();
			m.setCustid(custid);
			m.setPwd(pwd);
			boolean Login = m.Login();
			String name = m.getName();
			String Accno = m.getAccno();
			int balance = m.getBalance();
			if(Login==true)
			{	
				try
				{
						HttpSession Session = request.getSession(true);
						Session.setAttribute("name", name);
						Session.setAttribute("Accno", Accno);
						Session.setAttribute("balance", balance);
						response.sendRedirect("Dashboard.jsp");
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				try 
				{
					response.sendRedirect("LoginFailed.jsp");
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
}




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BankingModel 
{
	String url = "jdbc:mysql://localhost:3306/Banking";
	 String username = "root";
	 String password = "varun8055";
	 
	 String custid;
	 String pwd;
	 String name;
	 String Accno;
	 String npwd;
	 int balance;
	 Connection con;
	 PreparedStatement pstmt;
 	 ResultSet res;
	 
	 
	 public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccno() {
		return Accno;
	}
	public void setAccno(String Accno) {
		this.Accno = Accno;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getNpwd() {
		return npwd;
	}
	public void setNpwd(String npwd) {
		this.npwd = npwd;
	}
	public void Model()
	 {
		 try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
			}
			catch (ClassNotFoundException | SQLException e) 
			{
				e.printStackTrace();
			}
	 }
	 public boolean Login()
	 {
		 String s= "select * from banking.customer where custid=? and password=?";
		 try 
		 {
			 pstmt=con.prepareStatement(s);
			 pstmt.setString(1,custid);
			 pstmt.setString(2,pwd);
			 res = pstmt.executeQuery();
			while(res.next()==true)
			{
				 name = res.getString(1);
				 custid= res.getString(2);
				 password = res.getString(3);
				 Accno = res.getString(4);
				 balance = res.getInt(5);
				 return true;
			}
		 } 
		 catch (SQLException e) 
		 {
			e.printStackTrace();
		}
		 return false;
		
	 }
	 
	 public boolean changePasssword()
	 {
		 String s = "Update password from banking.customer set password =? where Accno = ?";
		 try 
		 {
			pstmt = con.prepareStatement(s);
			pstmt.setString(1, npwd);
			pstmt.setString(2, Accno);
			int a = pstmt.executeUpdate();
			if(a==1)
			{
				return true;
			}
		 } 
		 catch (SQLException e) 
		 {
			e.printStackTrace();
		}
		 return false;
		 
	 }
	 
}

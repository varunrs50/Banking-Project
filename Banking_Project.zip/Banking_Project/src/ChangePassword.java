import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ChangePassword extends HttpServlet
{
	public void service(HttpServletResponse response,HttpServletRequest request)
	{
		String npwd = request.getParameter("npwd");
		HttpSession session = request.getSession();
		session.getAttribute("Accno");
		BankingModel m = new BankingModel();
		m.setNpwd(npwd);
		m.setAccno("Accno");
		boolean changePasssword = m.changePasssword();
		if(changePasssword==true)
		{
			try 
			{
				response.sendRedirect("PasswordChangeSuccess.jsp");
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		else
		{
			try 
			{
				response.sendRedirect("PasswordChangeFailed.jsp");
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
}